export IRAF_DIR=/iraf
export iraf=$IRAF_DIR/iraf/
export MACH=linux64
export IRAFARCH=linux64
source ${iraf}/unix/hlib/irafuser.sh
export C_INCLUDE_PATH=$IRAF_DIR/include
export PATH=$IRAF_DIR/bin:$PATH

export tables=$IRAF_DIR/iraf/extern/tables/
export stsdas=$IRAF_DIR/iraf/extern/stsdas/
